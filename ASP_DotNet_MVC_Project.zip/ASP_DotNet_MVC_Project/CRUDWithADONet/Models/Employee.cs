﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace CRUDWithADONet.Models
{
    public class Employee
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [DisplayName("Employee Name")]
        public string Name { get; set; }

        [Required]
        [DisplayName("Employee Email")]
        public string Email { get; set; }

        [Required]
        [DisplayName("Employee Age")]
        public int Age { get; set; }
    }
}
