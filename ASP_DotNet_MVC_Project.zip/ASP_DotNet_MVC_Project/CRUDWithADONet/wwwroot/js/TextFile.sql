﻿-- Creating the database
Create Database MvcCrudAdo

-- Using the database
Use MvcCrudAdo

-- create the table
Create table Users(
Id int primary key Identity,
Name varchar(50),
Email varchar(50),
Age int
)

-- create store procedure for insert
Create Procedure sp_insert
@name varchar(50),
@email varchar(50),
@age int
as
begin
	insert into Users values(@name,@email,@age)
end


-- create store procedure for update
Create Procedure sp_update
@name varchar(50),
@email varchar(50),
@age int,
@id int
as
begin
	Update Users set Name=@name, Email=@email, Age=@age where Id=@id
end

-- create store procedure for delete
Create Procedure sp_delete
@id int
as
begin
	Delete from Users where Id=@id
end

-- create store procedure for select
Create Procedure sp_select
as
begin
	select * from Users
end

-- create store procedure for select via Id
Create Procedure sp_selectbyId
@id int
as
begin
	select Id, Name, Email, Age from Users where Id = @id
end



select * from Users